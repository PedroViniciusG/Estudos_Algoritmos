# Aula 01 - Introdução a Algoritmos

Tipo: Aula
Data: 1 de agosto de 2023
Link da Aula / Arquivos:  https://www.cursoemvideo.com/curso/curso-de-algoritmo/aulas/algoritmo/modulos/introducao-a-algoritmos/
Status: Assistido / Feito

# O que são Algoritmos?

> Algoritmos são conjuntos de passos finitos e organizados que, quando executados, resolvem um determinado problema.
> 

> Os passos de um Algoritmo são lidos de cima para baixo e da esquerda para direita.
>